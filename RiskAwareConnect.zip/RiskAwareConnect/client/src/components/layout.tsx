import { Link } from "wouter";
import { AlertTriangle, Heart, Globe, User, History, LogOut } from "lucide-react";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { t, language, setLanguage } = useLanguage();
  const { user, logout, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background font-sans text-foreground selection:bg-primary/20">
      {/* Safety Banner */}
      <div className="bg-secondary/50 text-secondary-foreground px-4 py-2 text-xs md:text-sm text-center font-medium border-b border-secondary/20">
        <span className="inline-flex items-center gap-2 justify-center">
          <AlertTriangle className="h-3 w-3 md:h-4 md:w-4" />
          {t('banner.safety')}
        </span>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Heart className="h-5 w-5 fill-current" />
            </div>
            <span className="font-serif text-lg md:text-xl font-bold text-foreground tracking-tight">
              Breast Health <span className="text-primary font-normal">Awareness</span>
            </span>
          </Link>

          <div className="flex items-center gap-2 md:gap-6">
            <nav className="hidden md:flex gap-6 text-sm font-medium text-muted-foreground">
              <Link href="/" className="hover:text-primary transition-colors">{t('nav.home')}</Link>
              <Link href="/assessment" className="hover:text-primary transition-colors">{t('nav.assessment')}</Link>
              <Link href="/resources" className="hover:text-primary transition-colors">{t('nav.resources')}</Link>
              <Link href="/support" className="hover:text-primary transition-colors">{t('nav.support')}</Link>
              {isAuthenticated && (
                <>
                  <Link href="/history" className="hover:text-primary transition-colors">History</Link>
                  <Link href="/plans" className="hover:text-primary transition-colors">My Plans</Link>
                </>
              )}
            </nav>

            {/* Language Switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 h-8 md:h-10">
                  <Globe className="h-4 w-4" />
                  <span className="hidden sm:inline">{language === 'en' ? 'English' : 'हिंदी'}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLanguage('en')}>
                  English
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('hi')}>
                  हिंदी (Hindi)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Menu */}
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-2 h-8 md:h-10">
                    <User className="h-4 w-4" />
                    <span className="hidden sm:inline">{user?.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <div className="px-2 py-1.5 text-sm font-medium text-muted-foreground">
                    {user?.email}
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/history" className="cursor-pointer w-full flex items-center">
                      <History className="mr-2 h-4 w-4" /> Assessment History
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout} className="text-red-600 focus:text-red-600">
                    <LogOut className="mr-2 h-4 w-4" /> Log Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/login">
                <Button variant="default" size="sm">Log In</Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-muted/30 border-t py-12 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="font-serif text-lg font-bold mb-4">Disclaimer</h3>
              <p className="text-sm text-muted-foreground leading-relaxed max-w-md">
                This web application calculates risk based on general statistical factors. 
                It does <strong>not</strong> provide a medical diagnosis. 
                If you feel a lump, have discharge, or notice skin changes, 
                please see a doctor immediately regardless of the result here.
              </p>
            </div>
            <div className="md:text-right">
              <h3 className="font-serif text-lg font-bold mb-4">Emergency Signs</h3>
              <ul className="text-sm text-muted-foreground space-y-2 inline-block text-left">
                <li>• Hard lump in breast or underarm</li>
                <li>• Bloody or clear nipple discharge</li>
                <li>• Skin dimpling or puckering</li>
                <li>• Redness or flaky skin in nipple area</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-xs text-muted-foreground">
            <p>© 2025 Breast Health Awareness Initiative. Educational Purpose Only.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
