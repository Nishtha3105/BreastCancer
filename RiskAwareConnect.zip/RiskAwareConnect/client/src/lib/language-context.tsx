import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'hi';

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

export const translations: Translations = {
  en: {
    "app.title": "Breast Health Awareness",
    "app.subtitle": "Educational Tool",
    "nav.home": "Home",
    "nav.assessment": "Assessment",
    "nav.resources": "Resources",
    "nav.support": "Help Desk",
    "banner.safety": "This is an educational tool, not a medical diagnosis. Please consult a doctor for concerns.",
    "hero.badge": "Early detection saves lives",
    "hero.title": "Empowering Indian Women with Health Awareness",
    "hero.desc": "Understand your breast health risk factors with our simple, private, and educational assessment tool. Knowledge is your first line of defense.",
    "hero.cta": "Check My Risk Score",
    "hero.secondary": "Learn Prevention Tips",
    "feature.risk": "Risk Estimation",
    "feature.risk.desc": "Uses statistical models to estimate your risk based on age, lifestyle, and family history.",
    "feature.prevent": "Prevention First",
    "feature.prevent.desc": "Get personalized tips on diet, exercise, and self-examination to lower your risk.",
    "feature.help": "Find Help Nearby",
    "feature.help.desc": "Instantly locate gynecologists and specialists in your city.",
    "assessment.title": "Health Risk Assessment",
    "assessment.desc": "Please answer the following questions honestly. Your data is processed locally.",
    "form.age": "Age (years)",
    "form.city": "City",
    "form.height": "Height (cm)",
    "form.weight": "Weight (kg)",
    "form.activity": "Physical Activity Level",
    "form.diet": "Diet Habits",
    "form.history": "Family History of Breast Cancer",
    "form.issues": "Previous Breast Issues/Lumps",
    "form.chronic": "Chronic Conditions (Diabetes, etc.)",
    "btn.submit": "Calculate Risk Assessment",
    "btn.analyzing": "Analyzing...",
    "result.title": "Your Assessment Result",
    "result.risk": "Estimated Risk Level",
    "result.recommendation": "Recommendation",
    "result.disclaimer": "Important: This result is an estimate. It is not a cancer diagnosis.",
    "result.find_doc": "Find Help",
    "result.search_maps": "Search on Google Maps",
    "prevention.title": "Lifetime Prevention & Healthy Habits",
    "prevention.intro": "Even if your risk is low, maintaining these habits can help prevent issues in the future.",
    "support.title": "24/7 Help Desk Support",
    "support.desc": "Have questions? Chat with our support assistant or find emergency contacts.",
    "support.chat_placeholder": "Type your question here...",
    "support.send": "Send Message",
  },
  hi: {
    "app.title": "स्तन स्वास्थ्य जागरूकता",
    "app.subtitle": "शैक्षिक उपकरण",
    "nav.home": "होम",
    "nav.assessment": "जाँच (Assessment)",
    "nav.resources": "संसाधन (Resources)",
    "nav.support": "सहायता (Help Desk)",
    "banner.safety": "यह एक शैक्षिक उपकरण है, चिकित्सा निदान नहीं। कृपया चिंता होने पर डॉक्टर से सलाह लें।",
    "hero.badge": "शीघ्र पता लगाने से जान बचती है",
    "hero.title": "स्वास्थ्य जागरूकता के साथ भारतीय महिलाओं को सशक्त बनाना",
    "hero.desc": "हमारे सरल, निजी और शैक्षिक उपकरण के साथ अपने स्तन स्वास्थ्य जोखिम कारकों को समझें।",
    "hero.cta": "मेरा जोखिम स्कोर जांचें",
    "hero.secondary": "रोकथाम के सुझाव जानें",
    "feature.risk": "जोखिम अनुमान",
    "feature.risk.desc": "आयु, जीवन शैली और पारिवारिक इतिहास के आधार पर आपके जोखिम का अनुमान लगाता है।",
    "feature.prevent": "रोकथाम पहले",
    "feature.prevent.desc": "अपने जोखिम को कम करने के लिए आहार, व्यायाम और आत्म-परीक्षण पर व्यक्तिगत सुझाव प्राप्त करें।",
    "feature.help": "नज़दीकी मदद खोजें",
    "feature.help.desc": "तुरंत अपने शहर में स्त्री रोग विशेषज्ञों और विशेषज्ञों का पता लगाएं।",
    "assessment.title": "स्वास्थ्य जोखिम मूल्यांकन",
    "assessment.desc": "कृपया निम्नलिखित प्रश्नों का उत्तर ईमानदारी से दें। आपका डेटा सुरक्षित है।",
    "form.age": "उम्र (वर्ष)",
    "form.city": "शहर",
    "form.height": "ऊंचाई (सेमी)",
    "form.weight": "वजन (किग्रा)",
    "form.activity": "शारीरिक गतिविधि का स्तर",
    "form.diet": "आहार की आदतें",
    "form.history": "स्तन कैंसर का पारिवारिक इतिहास",
    "form.issues": "पिछली स्तन समस्याएं / गांठ",
    "form.chronic": "दीर्घकालिक स्थितियां (मधुमेह, आदि)",
    "btn.submit": "जोखिम मूल्यांकन की गणना करें",
    "btn.analyzing": "विश्लेषण कर रहा है...",
    "result.title": "आपका मूल्यांकन परिणाम",
    "result.risk": "अनुमानित जोखिम स्तर",
    "result.recommendation": "सुझाव",
    "result.disclaimer": "महत्वपूर्ण: यह परिणाम एक अनुमान है। यह कैंसर का निदान नहीं है।",
    "result.find_doc": "मदद खोजें",
    "result.search_maps": "गूगल मैप्स पर खोजें",
    "prevention.title": "आजीवन रोकथाम और स्वस्थ आदतें",
    "prevention.intro": "भले ही आपका जोखिम कम हो, इन आदतों को बनाए रखने से भविष्य में समस्याओं को रोकने में मदद मिल सकती है।",
    "support.title": "24/7 सहायता केंद्र",
    "support.desc": "कोई सवाल? हमारे सहायता सहायक से चैट करें या आपातकालीन संपर्क खोजें।",
    "support.chat_placeholder": "अपना प्रश्न यहाँ लिखें...",
    "support.send": "संदेश भेजें",
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
