export type ActivityLevel = 'low' | 'moderate' | 'high';
export type DietHabit = 'very_healthy' | 'somewhat_healthy' | 'mixed' | 'unhealthy';

export interface RiskInput {
  age: number;
  weight: number; // kg
  height: number; // cm
  activityLevel: ActivityLevel;
  diet: DietHabit;
  familyHistory: boolean;
  prevIssues: boolean;
  chronicConditions: boolean;
  city: string;
}

export interface RiskResult {
  bmi: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  probability: number; // 0-100
  factors: string[];
  recommendation: string;
}

export function calculateBMI(weight: number, heightCm: number): number {
  const heightM = heightCm / 100;
  return parseFloat((weight / (heightM * heightM)).toFixed(1));
}

export function calculateRisk(input: RiskInput): RiskResult {
  let riskScore = 0;
  const factors: string[] = [];

  // 1. Base Risk (Baseline)
  riskScore += 5;

  // 2. Age Factor
  if (input.age > 55) {
    riskScore += 20;
    factors.push("Age above 55");
  } else if (input.age > 45) {
    riskScore += 15;
    factors.push("Age above 45");
  } else if (input.age > 35) {
    riskScore += 5;
  }

  // 3. BMI Factor
  const bmi = calculateBMI(input.weight, input.height);
  if (bmi >= 30) {
    riskScore += 15;
    factors.push(`High BMI (${bmi})`);
  } else if (bmi >= 25) {
    riskScore += 10;
    factors.push(`Overweight (BMI ${bmi})`);
  }

  // 4. Activity Level
  if (input.activityLevel === 'low') {
    riskScore += 10;
    factors.push("Low physical activity");
  } else if (input.activityLevel === 'moderate') {
    riskScore += 0; // Neutral
  } else {
    riskScore -= 5; // Protective
  }

  // 5. Diet
  if (input.diet === 'unhealthy') {
    riskScore += 10;
    factors.push("Unhealthy diet");
  } else if (input.diet === 'mixed') {
    riskScore += 5;
    factors.push("Mixed diet");
  }

  // 6. Family History (Strongest Factor in this simple model)
  if (input.familyHistory) {
    riskScore += 25;
    factors.push("Family history of breast cancer");
  }

  // 7. Previous Issues
  if (input.prevIssues) {
    riskScore += 20;
    factors.push("Previous breast issues/lumps");
  }

  // 8. Chronic Conditions
  if (input.chronicConditions) {
    riskScore += 10;
    factors.push("Chronic medical conditions");
  }

  // Normalize Probability (Cap at 95% for realism in high risk, floor at 2%)
  const probability = Math.min(Math.max(riskScore, 2), 95);

  // Determine Category
  let riskLevel: 'Low' | 'Medium' | 'High' = 'Low';
  let recommendation = "";

  if (probability >= 60) {
    riskLevel = 'High';
    recommendation = "We strongly recommend visiting a gynaecologist or breast specialist as soon as possible for a comprehensive screening.";
  } else if (probability >= 30) {
    riskLevel = 'Medium';
    recommendation = "Consider discussing screening options and regular check-ups with a doctor. Stay vigilant with self-exams.";
  } else {
    riskLevel = 'Low';
    recommendation = "Your estimated risk is lower, but regular self-exams and maintaining a healthy lifestyle are still vital.";
  }

  return {
    bmi,
    riskLevel,
    probability,
    factors,
    recommendation
  };
}
