import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Phone, User, Bot } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function Support() {
  const { t } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Namaste! I am your Breast Health Assistant. How can I help you today? You can ask about symptoms, prevention, or finding a doctor.",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newUserMsg: Message = {
      id: messages.length + 1,
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputValue("");

    // Simulate bot response
    setTimeout(() => {
      let botResponseText = "Thank you for your question. For accurate medical advice, please consult a specialist. However, generally speaking, maintaining a healthy diet and regular exercise helps in prevention.";
      
      if (newUserMsg.text.toLowerCase().includes("prevention") || newUserMsg.text.toLowerCase().includes("prevent")) {
         botResponseText = "Prevention starts with a healthy lifestyle: 1. Maintain healthy weight. 2. Exercise 30 mins daily. 3. Avoid smoking/alcohol. 4. Monthly self-exams.";
      } else if (newUserMsg.text.toLowerCase().includes("lump") || newUserMsg.text.toLowerCase().includes("pain")) {
         botResponseText = "If you feel a lump or pain, please do not panic, but DO visit a doctor immediately. Early check-up is the best step.";
      }

      const newBotMsg: Message = {
        id: messages.length + 2,
        text: botResponseText,
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, newBotMsg]);
    }, 1000);
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl animate-in fade-in duration-500">
      <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4 text-foreground text-center">
        {t('support.title')}
      </h1>
      <p className="text-center text-muted-foreground mb-8 max-w-2xl mx-auto">
        {t('support.desc')}
      </p>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Chat Interface */}
        <Card className="md:col-span-2 h-[600px] flex flex-col shadow-lg border-primary/10">
          <CardHeader className="bg-primary/5 border-b">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Bot className="h-5 w-5 text-primary" /> 
              Health Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-0 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    <Avatar className="h-8 w-8 mt-1">
                      <AvatarFallback className={msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}>
                        {msg.sender === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`rounded-lg p-3 max-w-[80%] text-sm ${
                        msg.sender === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-foreground'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t bg-background">
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <Input 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={t('support.chat_placeholder')}
                  className="flex-1"
                />
                <Button type="submit" size="icon">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-serif">Emergency Contacts</CardTitle>
              <CardDescription>Available 24/7 for urgent queries</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-green-50 text-green-800 rounded-lg border border-green-100">
                <Phone className="h-5 w-5" />
                <div>
                  <div className="font-bold">National Health Helpline</div>
                  <div className="text-lg">1800-11-6666</div>
                </div>
              </div>
              
               <div className="flex items-center gap-3 p-3 bg-blue-50 text-blue-800 rounded-lg border border-blue-100">
                <Phone className="h-5 w-5" />
                <div>
                  <div className="font-bold">Women's Helpline</div>
                  <div className="text-lg">1091</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg font-serif">Scalable Support</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                This help desk system is designed to scale. In a full production environment, 
                this would connect to a real AI backend or live agent support system using WebSockets for real-time communication.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
