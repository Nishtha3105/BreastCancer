import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { RiskResult, RiskInput } from "@/lib/risk-calculator";
import { Calendar, ChevronRight, History, AlertTriangle, CheckCircle2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { format } from "date-fns";

interface HistoryItem {
  date: string;
  result: RiskResult;
  input: RiskInput;
}

export default function UserHistory() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    const storedHistory = localStorage.getItem("userHistory");
    if (storedHistory) {
      const parsed = JSON.parse(storedHistory);
      // Sort by date descending
      setHistory(parsed.sort((a: HistoryItem, b: HistoryItem) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) return null;

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'High': return 'text-red-600 bg-red-50 border-red-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-green-600 bg-green-50 border-green-200';
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">My Assessment History</h1>
          <p className="text-muted-foreground">Track your risk factors over time, {user?.name}.</p>
        </div>
        <Link href="/assessment">
          <Button>New Assessment</Button>
        </Link>
      </div>

      {history.length === 0 ? (
        <Card className="bg-muted/20 border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <History className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No History Yet</h3>
            <p className="text-muted-foreground mb-6 max-w-sm">
              You haven't completed any risk assessments yet. Take your first step towards awareness today.
            </p>
            <Link href="/assessment">
              <Button>Start Assessment</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {history.map((item, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => {
              // Store this specific result as current for the Result page
              localStorage.setItem("riskAssessmentResult", JSON.stringify({ result: item.result, input: item.input }));
              navigate("/result");
            }}>
              <CardContent className="p-6 flex items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className={`h-12 w-12 rounded-full flex items-center justify-center border shrink-0 ${getRiskColor(item.result.riskLevel)}`}>
                    {item.result.riskLevel === 'High' ? <AlertTriangle className="h-5 w-5" /> : <CheckCircle2 className="h-5 w-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                      <Calendar className="h-4 w-4" />
                      {format(new Date(item.date), 'MMMM d, yyyy')}
                    </div>
                    <h3 className="font-bold text-lg">
                      {item.result.riskLevel} Risk Assessment
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      BMI: {item.result.bmi} • {item.result.factors.length} Risk Factors Identified
                    </p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
