import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Activity, Heart, ShieldCheck } from "lucide-react";
import { useLanguage } from "@/lib/language-context";
import heroImage from "@assets/generated_images/soft_abstract_comforting_background_with_pink_and_teal_waves.png";

export default function Home() {
  const { t } = useLanguage();

  return (
    <div className="animate-in fade-in duration-500">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-24 md:pt-24 md:pb-32">
        <div className="absolute inset-0 -z-10 opacity-20">
           <img 
            src={heroImage} 
            alt="Soft background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/50 to-background"></div>
        </div>

        <div className="container mx-auto px-4 text-center max-w-3xl">
          <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm text-primary mb-6 backdrop-blur-sm">
            <span className="flex h-2 w-2 rounded-full bg-primary mr-2"></span>
            {t('hero.badge')}
          </div>
          
          <h1 className="text-4xl md:text-6xl font-serif font-bold tracking-tight text-foreground mb-6 leading-tight">
            {t('hero.title')}
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed">
            {t('hero.desc')}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/assessment">
              <Button size="lg" className="rounded-full px-8 text-lg h-12 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all hover:-translate-y-0.5">
                {t('hero.cta')} <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/resources">
              <Button variant="outline" size="lg" className="rounded-full px-8 text-lg h-12 bg-background/50 backdrop-blur-sm hover:bg-background/80">
                {t('hero.secondary')}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card p-8 rounded-2xl shadow-sm border hover:shadow-md transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                <Activity className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3">{t('feature.risk')}</h3>
              <p className="text-muted-foreground">
                {t('feature.risk.desc')}
              </p>
            </div>
            
            <div className="bg-card p-8 rounded-2xl shadow-sm border hover:shadow-md transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-secondary/20 flex items-center justify-center text-secondary-foreground mb-6">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3">{t('feature.prevent')}</h3>
              <p className="text-muted-foreground">
                {t('feature.prevent.desc')}
              </p>
            </div>
            
            <div className="bg-card p-8 rounded-2xl shadow-sm border hover:shadow-md transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 mb-6">
                <Heart className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-serif font-bold mb-3">{t('feature.help')}</h3>
              <p className="text-muted-foreground">
                {t('feature.help.desc')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Important Note */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="bg-primary/5 rounded-3xl p-8 md:p-12 border border-primary/10 text-center max-w-4xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-serif font-bold mb-4">Why is this important?</h2>
            <p className="text-muted-foreground text-lg mb-6">
              Breast cancer is increasingly common in India, often detected late due to lack of awareness. 
              Regular screening and self-exams can significantly improve outcomes.
            </p>
            <p className="font-medium text-foreground">
              This tool is a starting point for conversation with your doctor.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
