import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CheckCircle2, AlertCircle } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

export default function Resources() {
  const { t } = useLanguage();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl animate-in fade-in duration-500">
      <h1 className="text-3xl md:text-4xl font-serif font-bold mb-8 text-foreground text-center">
        {t('nav.resources')}
      </h1>

      {/* Self Exam Guide */}
      <section className="mb-12">
        <Card>
          <CardHeader className="bg-primary/5">
            <CardTitle className="font-serif text-2xl text-primary-foreground md:text-primary">How to Perform a Self-Exam</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <p className="mb-4 text-muted-foreground">
                  Checking your breasts regularly can help you understand what is normal for you. 
                  If you notice any changes, see a doctor immediately.
                </p>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <span className="bg-primary/10 text-primary font-bold h-6 w-6 rounded-full flex items-center justify-center shrink-0">1</span>
                    <span><strong>In the Shower:</strong> Using the pads of your fingers, move around your entire breast in a circular pattern moving from the outside to the center, checking the entire breast and armpit area. Check both breasts feeling for any lump, thickening, or hardened knot.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="bg-primary/10 text-primary font-bold h-6 w-6 rounded-full flex items-center justify-center shrink-0">2</span>
                    <span><strong>In Front of a Mirror:</strong> Visually inspect your breasts with your arms at your sides. Next, raise your arms high overhead. Look for any changes in the contour, any swelling, or dimpling of the skin, or changes in the nipples.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="bg-primary/10 text-primary font-bold h-6 w-6 rounded-full flex items-center justify-center shrink-0">3</span>
                    <span><strong>Lying Down:</strong> When lying down, the breast tissue spreads out evenly along the chest wall. Place a pillow under your right shoulder and your right arm behind your head. Using your left hand, move the pads of your fingers around your right breast gently in small circular motions covering the entire breast area and armpit. Use light, medium, and firm pressure. Squeeze the nipple; check for discharge and lumps. Repeat these steps for your left breast.</span>
                  </li>
                </ul>
              </div>
              <div className="bg-muted rounded-xl p-8 flex items-center justify-center text-center text-muted-foreground h-64">
                 {/* Placeholder for an illustration */}
                 <div className="space-y-2">
                   <div className="text-4xl">🧴 🚿 🛏️</div>
                   <p>Perform once a month,<br/>preferably after your period.</p>
                 </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Warning Signs */}
      <section className="mb-12">
        <h2 className="text-2xl font-serif font-bold mb-6">Signs & Symptoms to Watch For</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-red-50 p-6 rounded-xl border border-red-100">
            <div className="flex items-center gap-3 mb-4 text-red-700 font-bold">
              <AlertCircle className="h-6 w-6" />
              <span>Consult a Doctor Immediately If:</span>
            </div>
            <ul className="space-y-2 text-red-900/80 list-disc list-inside">
              <li>New lump in the breast or underarm (armpit).</li>
              <li>Thickening or swelling of part of the breast.</li>
              <li>Irritation or dimpling of breast skin.</li>
              <li>Redness or flaky skin in the nipple area or the breast.</li>
              <li>Pulling in of the nipple or pain in the nipple area.</li>
              <li>Nipple discharge other than breast milk, including blood.</li>
              <li>Any change in the size or the shape of the breast.</li>
              <li>Pain in any area of the breast.</li>
            </ul>
          </div>
          
          <div className="bg-green-50 p-6 rounded-xl border border-green-100">
             <div className="flex items-center gap-3 mb-4 text-green-700 font-bold">
              <CheckCircle2 className="h-6 w-6" />
              <span>Healthy Habits (Prevention)</span>
            </div>
            <ul className="space-y-2 text-green-900/80 list-disc list-inside">
              <li>Maintain a healthy weight.</li>
              <li>Exercise regularly (at least 4 hours a week).</li>
              <li>Limit alcohol intake.</li>
              <li>Avoid exposure to tobacco smoke.</li>
              <li>Breastfeed, if possible.</li>
              <li>Limit dose and duration of hormone therapy.</li>
              <li>Avoid exposure to radiation and environmental pollution.</li>
            </ul>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section>
        <h2 className="text-2xl font-serif font-bold mb-6">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger>What is the best time for a self-exam?</AccordionTrigger>
            <AccordionContent>
              The best time to perform a breast self-exam is about 3 to 5 days after your period starts. Your breasts are less likely to be tender or swollen at this time. If you have gone through menopause, try to do the exam on the same day every month.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-2">
            <AccordionTrigger>Does a lump always mean cancer?</AccordionTrigger>
            <AccordionContent>
              No. Most breast lumps are benign (not cancer). They can be cysts, fibroadenomas, or other non-cancerous conditions. However, you should always get any new lump checked by a doctor to be sure.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-3">
            <AccordionTrigger>What is a mammogram?</AccordionTrigger>
            <AccordionContent>
              A mammogram is an X-ray picture of the breast. Doctors use a mammogram to look for early signs of breast cancer. Regular mammograms are the best tests doctors have to find breast cancer early.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </section>
    </div>
  );
}
