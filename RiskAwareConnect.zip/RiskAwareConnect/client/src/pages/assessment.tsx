import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { calculateRisk } from "@/lib/risk-calculator";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";

const formSchema = z.object({
  age: z.coerce.number().min(18, "You must be at least 18 years old").max(100, "Please enter a valid age"),
  weight: z.coerce.number().min(30, "Please enter a valid weight in kg").max(200),
  height: z.coerce.number().min(100, "Please enter a valid height in cm").max(250),
  activityLevel: z.enum(["low", "moderate", "high"], {
    required_error: "Please select an activity level",
  }),
  diet: z.enum(["very_healthy", "somewhat_healthy", "mixed", "unhealthy"], {
    required_error: "Please select a diet type",
  }),
  familyHistory: z.enum(["yes", "no"], {
    required_error: "Please select yes or no",
  }),
  prevIssues: z.enum(["yes", "no"], {
    required_error: "Please select yes or no",
  }),
  chronicConditions: z.enum(["yes", "no"], {
    required_error: "Please select yes or no",
  }),
  city: z.string().min(2, "Please enter your city"),
});

export default function Assessment() {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: undefined,
      weight: undefined,
      height: undefined,
      city: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    
    // Simulate processing delay for "Analysis" feel
    setTimeout(() => {
      const input = {
        ...values,
        familyHistory: values.familyHistory === "yes",
        prevIssues: values.prevIssues === "yes",
        chronicConditions: values.chronicConditions === "yes",
      };

      const result = calculateRisk(input);
      
      // Store result in localStorage to pass to result page
      localStorage.setItem("riskAssessmentResult", JSON.stringify({ result, input }));
      
      // If logged in, save to history
      if (isAuthenticated) {
        const historyItem = {
          date: new Date().toISOString(),
          result,
          input
        };
        
        const existingHistory = localStorage.getItem("userHistory");
        const history = existingHistory ? JSON.parse(existingHistory) : [];
        history.push(historyItem);
        localStorage.setItem("userHistory", JSON.stringify(history));
      }
      
      setIsSubmitting(false);
      navigate("/result");
    }, 1500);
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl animate-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4 text-foreground">{t('assessment.title')}</h1>
        <p className="text-muted-foreground">
          {t('assessment.desc')}
        </p>
      </div>

      <Card className="shadow-lg border-primary/10">
        <CardHeader className="bg-muted/30 border-b">
          <CardTitle className="font-serif">Personal Information</CardTitle>
          <CardDescription>Basic details to calculate your BMI and baseline risk.</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              
              {/* Section 1: Basic Vitals */}
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.age')}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="e.g. 45" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.city')}</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Mumbai" {...field} />
                      </FormControl>
                      <FormDescription>Used to find nearby doctors</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="height"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.height')}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="e.g. 160" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.weight')}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="e.g. 65" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator className="my-4" />
              
              {/* Section 2: Lifestyle */}
              <div className="space-y-6">
                <h3 className="font-serif text-lg font-medium">Lifestyle Factors</h3>
                
                <FormField
                  control={form.control}
                  name="activityLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.activity')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="low" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Low (Sedentary, little to no exercise)
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="moderate" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Moderate (Light exercise 1-3 times/week)
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="high" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              High (Active daily exercise/sports)
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="diet"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('form.diet')}</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your diet type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="very_healthy">Very Healthy (Balanced, lots of veggies/fruit)</SelectItem>
                          <SelectItem value="somewhat_healthy">Somewhat Healthy</SelectItem>
                          <SelectItem value="mixed">Mixed (Home cooked + frequent processed food)</SelectItem>
                          <SelectItem value="unhealthy">Unhealthy (Mostly processed/oily food)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator className="my-4" />

              {/* Section 3: Medical History */}
              <div className="space-y-6">
                <h3 className="font-serif text-lg font-medium">Medical History</h3>

                <FormField
                  control={form.control}
                  name="familyHistory"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>{t('form.history')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-row space-x-4"
                        >
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="yes" />
                            </FormControl>
                            <FormLabel className="font-normal">Yes</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="no" />
                            </FormControl>
                            <FormLabel className="font-normal">No</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="prevIssues"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>{t('form.issues')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-row space-x-4"
                        >
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="yes" />
                            </FormControl>
                            <FormLabel className="font-normal">Yes</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="no" />
                            </FormControl>
                            <FormLabel className="font-normal">No</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="chronicConditions"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>{t('form.chronic')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-row space-x-4"
                        >
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="yes" />
                            </FormControl>
                            <FormLabel className="font-normal">Yes</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-2 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="no" />
                            </FormControl>
                            <FormLabel className="font-normal">No</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-6">
                <Button type="submit" size="lg" className="w-full text-lg h-12" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t('btn.analyzing')}
                    </>
                  ) : (
                    t('btn.submit')
                  )}
                </Button>
                <p className="text-xs text-muted-foreground text-center mt-4">
                  By continuing, you acknowledge that this is an educational tool and not a medical diagnosis.
                </p>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
