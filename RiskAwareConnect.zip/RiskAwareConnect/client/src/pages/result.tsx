import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { RiskResult, RiskInput } from "@/lib/risk-calculator";
import { AlertTriangle, MapPin, ArrowRight, RefreshCw, CheckCircle2, Activity, Calendar } from "lucide-react";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";

export default function Result() {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [data, setData] = useState<{ result: RiskResult; input: RiskInput } | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("riskAssessmentResult");
    if (!stored) {
      navigate("/assessment");
      return;
    }
    setData(JSON.parse(stored));
  }, [navigate]);

  if (!data) return null;

  const { result, input } = data;

  const riskColors = {
    Low: "text-green-600 bg-green-50 border-green-200",
    Medium: "text-yellow-600 bg-yellow-50 border-yellow-200",
    High: "text-red-600 bg-red-50 border-red-200",
  };

  const riskProgressColor = {
    Low: "bg-green-500",
    Medium: "bg-yellow-500",
    High: "bg-red-500",
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl animate-in fade-in duration-500">
      
      {/* Header Section */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-2 text-foreground">{t('result.title')}</h1>
        <p className="text-muted-foreground">Based on the information you provided.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        
        {/* Main Result Card */}
        <div className="md:col-span-2 space-y-6">
          <Card className={`border-2 shadow-sm ${riskColors[result.riskLevel]}`}>
            <CardContent className="pt-8 pb-8 text-center">
              <h2 className="text-lg font-medium uppercase tracking-wide mb-2 opacity-80">{t('result.risk')}</h2>
              <div className="text-5xl font-serif font-bold mb-4">{result.riskLevel}</div>
              
              <div className="w-full max-w-xs mx-auto mb-6">
                <div className="flex justify-between text-xs mb-2 opacity-70">
                  <span>Low</span>
                  <span>Medium</span>
                  <span>High</span>
                </div>
                <Progress value={result.probability} className="h-3 bg-black/10" indicatorClassName={riskProgressColor[result.riskLevel]} />
              </div>

              <p className="text-lg font-medium px-6 leading-relaxed">
                {result.recommendation}
              </p>
            </CardContent>
          </Card>

          {/* Details */}
          <Card>
            <CardHeader>
              <CardTitle className="font-serif">Detailed Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div>
                  <div className="text-sm text-muted-foreground">Your BMI</div>
                  <div className="text-2xl font-bold">{result.bmi}</div>
                </div>
                <div className={`text-sm px-3 py-1 rounded-full ${result.bmi >= 25 ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                  {result.bmi >= 30 ? 'Obese' : result.bmi >= 25 ? 'Overweight' : 'Healthy Weight'}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Possible Contributing Factors:</h4>
                {result.factors.length > 0 ? (
                  <ul className="space-y-2">
                    {result.factors.map((factor, i) => (
                      <li key={i} className="flex items-start gap-2 text-muted-foreground">
                        <AlertTriangle className="h-5 w-5 text-yellow-500 shrink-0" />
                        {factor}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="flex items-center gap-2 text-green-600">
                     <CheckCircle2 className="h-5 w-5" />
                     No major risk factors identified based on your inputs.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Lifetime Prevention - New Section */}
          <Card className="bg-emerald-50 border-emerald-100">
             <CardHeader>
              <CardTitle className="font-serif text-emerald-800 flex items-center gap-2">
                <Activity className="h-5 w-5" />
                {t('prevention.title')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-emerald-800/80 mb-4">
                {t('prevention.intro')}
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                 <div className="bg-white p-3 rounded-lg border border-emerald-100 shadow-sm">
                    <div className="font-bold text-emerald-800 text-sm">Active Lifestyle</div>
                    <div className="text-xs text-muted-foreground">30 mins exercise, 5 days a week.</div>
                 </div>
                 <div className="bg-white p-3 rounded-lg border border-emerald-100 shadow-sm">
                    <div className="font-bold text-emerald-800 text-sm">Healthy Diet</div>
                    <div className="text-xs text-muted-foreground">Eat more fruits, vegetables, and whole grains.</div>
                 </div>
                 <div className="bg-white p-3 rounded-lg border border-emerald-100 shadow-sm">
                    <div className="font-bold text-emerald-800 text-sm">Monthly Checks</div>
                    <div className="text-xs text-muted-foreground">Self-exams are key to knowing your normal.</div>
                 </div>
              </div>
            </CardContent>
          </Card>

          {/* Disclaimer Again */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-sm text-blue-800">
            <strong>Important:</strong> {t('result.disclaimer')}
          </div>
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          
          {isAuthenticated ? (
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                 <CardTitle className="font-serif text-primary flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  My Plans
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  We've generated a personalized diet and exercise plan based on this result.
                </p>
                <Link href="/plans">
                  <Button className="w-full">View My Plans</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-muted/50">
              <CardContent className="pt-6 space-y-4">
                <p className="text-sm text-muted-foreground">
                  <strong>Log in</strong> to save this result to your history and get personalized diet plans.
                </p>
                <Link href="/login">
                  <Button variant="outline" className="w-full">Log In to Save</Button>
                </Link>
              </CardContent>
            </Card>
          )}

          {/* Find Doctor */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle className="font-serif flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                {t('result.find_doc')}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground mb-4">
                Locate gynaecologists and breast specialists near <strong>{input.city}</strong>.
              </p>
              <a 
                href={`https://www.google.com/maps/search/gynaecologist+near+${encodeURIComponent(input.city)}`}
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button variant="secondary" className="w-full shadow-sm">
                   {t('result.search_maps')} <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </a>
            </CardContent>
          </Card>

           <Link href="/assessment">
            <Button variant="ghost" className="w-full text-muted-foreground">
              <RefreshCw className="mr-2 h-4 w-4" /> Retake Assessment
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
