import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Utensils, Clock, CheckCircle2, AlertTriangle } from "lucide-react";

export default function Plans() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) return null;

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl animate-in fade-in duration-500">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-2 text-foreground">Your Personalized Plans</h1>
        <p className="text-muted-foreground">Tailored diet and exercise recommendations for {user?.name}.</p>
      </div>

      <Tabs defaultValue="exercise" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-[400px] mb-8">
          <TabsTrigger value="exercise">Exercise Plan</TabsTrigger>
          <TabsTrigger value="diet">Dietary Plan</TabsTrigger>
        </TabsList>

        {/* Exercise Plan */}
        <TabsContent value="exercise" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 bg-blue-50/50 border-blue-100">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif text-blue-800">
                  <Activity className="h-5 w-5" /> Moderate Activity Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-bold mb-2 text-blue-900">Weekly Goal: 150 Minutes</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Aim for at least 30 minutes of moderate activity, 5 days a week. This significantly reduces breast cancer risk.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex gap-4 items-start bg-white p-4 rounded-lg border shadow-sm">
                      <div className="bg-blue-100 p-2 rounded-full text-blue-600 font-bold">1</div>
                      <div>
                        <h4 className="font-bold text-blue-900">Brisk Walking</h4>
                        <p className="text-sm text-muted-foreground">Start with a 20-minute brisk walk every morning. Swing your arms to increase heart rate.</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-4 items-start bg-white p-4 rounded-lg border shadow-sm">
                       <div className="bg-blue-100 p-2 rounded-full text-blue-600 font-bold">2</div>
                      <div>
                        <h4 className="font-bold text-blue-900">Yoga & Stretching</h4>
                        <p className="text-sm text-muted-foreground">Focus on chest-opening poses (like Cobra or Camel pose) to improve lymphatic flow.</p>
                      </div>
                    </div>

                    <div className="flex gap-4 items-start bg-white p-4 rounded-lg border shadow-sm">
                       <div className="bg-blue-100 p-2 rounded-full text-blue-600 font-bold">3</div>
                      <div>
                        <h4 className="font-bold text-blue-900">Strength Training</h4>
                        <p className="text-sm text-muted-foreground">2 days a week, do light resistance exercises (pushups against wall, light dumbbells) to build bone density.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-serif">Daily Schedule</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">07:00 AM</span>
                    <span className="text-muted-foreground">20 min Brisk Walk</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">01:00 PM</span>
                    <span className="text-muted-foreground">5 min Desk Stretch</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">06:00 PM</span>
                    <span className="text-muted-foreground">15 min Yoga Flow</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground italic">
                    "Consistent, moderate exercise is better than intense, sporadic workouts."
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Diet Plan */}
        <TabsContent value="diet" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 bg-green-50/50 border-green-100">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif text-green-800">
                  <Utensils className="h-5 w-5" /> Anti-Inflammatory Diet
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-bold mb-2 text-green-900">Focus: Plant-Based & Whole Foods</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    A diet rich in antioxidants and fiber helps regulate hormones and reduce inflammation.
                  </p>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                      <h4 className="font-bold text-green-800 mb-2 flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4" /> Foods to Include
                      </h4>
                      <ul className="text-sm space-y-2 text-muted-foreground">
                        <li>• Cruciferous Veggies (Broccoli, Cauliflower)</li>
                        <li>• Berries & Citrus Fruits</li>
                        <li>• Flaxseeds & Walnuts (Omega-3)</li>
                        <li>• Turmeric & Ginger (Anti-inflammatory)</li>
                        <li>• Green Tea</li>
                      </ul>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                      <h4 className="font-bold text-red-800 mb-2 flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" /> Foods to Limit
                      </h4>
                      <ul className="text-sm space-y-2 text-muted-foreground">
                        <li>• Processed Meats & Red Meat</li>
                        <li>• Sugary Drinks & Sodas</li>
                        <li>• Alcohol (Limit to minimal)</li>
                        <li>• Refined Carbohydrates (White bread)</li>
                        <li>• Fried & Fast Foods</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-serif">Sample Meal Plan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                  <div>
                    <div className="font-bold text-foreground">Breakfast</div>
                    <div className="text-muted-foreground">Oatmeal with flaxseeds & berries</div>
                  </div>
                  <div className="h-px bg-border" />
                  <div>
                    <div className="font-bold text-foreground">Lunch</div>
                    <div className="text-muted-foreground">Lentil soup (Dal) with spinach & brown rice</div>
                  </div>
                  <div className="h-px bg-border" />
                  <div>
                    <div className="font-bold text-foreground">Snack</div>
                    <div className="text-muted-foreground">Handful of walnuts or an apple</div>
                  </div>
                  <div className="h-px bg-border" />
                  <div>
                    <div className="font-bold text-foreground">Dinner</div>
                    <div className="text-muted-foreground">Grilled fish/tofu with roasted vegetables</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
